# Revival Extras

Mod pequeno e separado que adiciona 42 DNAs (e as receitas do cultivador) para animais do
Prehistoric Fauna que o Prehistoric Revival 1.2.1 nao cobre. Nao altera nem copia o jar do Revival.

Tambem corrige DNAs que o Revival 1.2.1 ja traz mas nao funcionam:
Czekanowskia e Telmasaurus (faltavam na tag dna), Zamites (receita com item inexistente),
Osmundacaulis (sem fonte no analisador) e Horsetail (analisador apontava para um nome errado).

Requer: Forge 1.20.1, Prehistoric Fauna e Prehistoric Revival.

Como compilar: envie estes arquivos para um repositorio (de preferencia privado), abra a aba
Actions, rode o workflow "build" e baixe o artefato "revival_extras" (um zip com o .jar).
Coloque o .jar na pasta mods junto com o Revival e o Prehistoric Fauna.
