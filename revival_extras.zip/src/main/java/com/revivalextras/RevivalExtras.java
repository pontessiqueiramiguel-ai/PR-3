package com.revivalextras;

import java.util.LinkedHashMap;
import java.util.Map;

import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraftforge.eventbus.api.IEventBus;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

@Mod(RevivalExtras.MOD_ID)
public class RevivalExtras {
    public static final String MOD_ID = "revival_extras";

    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, MOD_ID);
    public static final DeferredRegister<CreativeModeTab> TABS = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, MOD_ID);

    /** nome do animal -> item de DNA */
    public static final Map<String, RegistryObject<Item>> DNAS = new LinkedHashMap<>();

    static {
        for (int i = 0; i < Animais.NOMES.length; i++) {
            final int primaria = Animais.COR_PRIMARIA[i];
            final int secundaria = Animais.COR_SECUNDARIA[i];
            RegistryObject<Item> dna = ITEMS.<Item>register(Animais.NOMES[i] + "_dna",
                    () -> new DnaItem(new Item.Properties(), primaria, secundaria));
            DNAS.put(Animais.NOMES[i], dna);
        }
    }

    public static final RegistryObject<CreativeModeTab> TAB = TABS.register("dna", () -> CreativeModeTab.builder()
            .title(Component.translatable("itemGroup.revival_extras"))
            .icon(() -> new ItemStack(DNAS.get("camptosaurus").get()))
            .displayItems((parameters, output) -> {
                for (RegistryObject<Item> dna : DNAS.values()) {
                    output.accept(dna.get());
                }
            })
            .build());

    public RevivalExtras() {
        IEventBus bus = FMLJavaModLoadingContext.get().getModEventBus();
        ITEMS.register(bus);
        TABS.register(bus);
    }
}
