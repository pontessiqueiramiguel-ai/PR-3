package com.revivalextras;

import java.util.List;

import net.minecraft.ChatFormatting;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.tags.TagKey;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.level.Level;

/** Seringa de DNA com duas cores e o mesmo tooltip do Prehistoric Revival. */
public class DnaItem extends Item {
    private static final String[] PERIODOS = {"cretaceous", "jurassic", "triassic"};
    private static final String[] FORMACOES = {"djadochta", "hell_creek", "yixian", "kayenta", "morrison", "chinle", "ischigualasto"};
    private static final String[] TIPOS = {"fish", "dinosaur", "bug", "synapsid", "reptile", "mammal", "pseudosuchian", "aquatic_plant", "ground_cover", "tree"};

    private final int primaryColor;
    private final int secondaryColor;

    public DnaItem(Item.Properties properties, int primaryColor, int secondaryColor) {
        super(properties);
        this.primaryColor = primaryColor;
        this.secondaryColor = secondaryColor;
    }

    public int getColor(int tintIndex) {
        if (tintIndex == 0) {
            return primaryColor;
        }
        if (tintIndex == 1) {
            return secondaryColor;
        }
        return -1;
    }

    @Override
    public void appendHoverText(ItemStack stack, Level level, List<Component> tooltip, TooltipFlag flag) {
        if (Screen.hasShiftDown()) {
            addLines(stack, tooltip, PERIODOS, ChatFormatting.DARK_GRAY);
            addLines(stack, tooltip, FORMACOES, ChatFormatting.GRAY);
            addLines(stack, tooltip, TIPOS, ChatFormatting.WHITE);
        } else {
            tooltip.add(Component.translatable("dna.hold_shift").withStyle(ChatFormatting.GRAY));
        }
    }

    private static void addLines(ItemStack stack, List<Component> tooltip, String[] chaves, ChatFormatting cor) {
        for (String chave : chaves) {
            TagKey<Item> tag = TagKey.create(Registries.ITEM, new ResourceLocation("prehistoric_revival", chave + "_dna"));
            if (stack.is(tag)) {
                tooltip.add(Component.translatable(chave).withStyle(cor));
            }
        }
    }
}
