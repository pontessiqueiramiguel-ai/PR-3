package com.revivalextras.client;

import com.revivalextras.DnaItem;
import com.revivalextras.RevivalExtras;

import net.minecraft.world.item.Item;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.RegisterColorHandlersEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.registries.RegistryObject;

@Mod.EventBusSubscriber(modid = RevivalExtras.MOD_ID, bus = Mod.EventBusSubscriber.Bus.MOD, value = Dist.CLIENT)
public class ClientEvents {

    @SubscribeEvent
    public static void registerItemColors(RegisterColorHandlersEvent.Item event) {
        for (RegistryObject<Item> dna : RevivalExtras.DNAS.values()) {
            event.register((stack, tintIndex) -> ((DnaItem) stack.getItem()).getColor(tintIndex), dna.get());
        }
    }
}
